package com.valtech.training.sprsecoauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprSecOauth2Application {

	public static void main(String[] args) {
		SpringApplication.run(SprSecOauth2Application.class, args);
	}

}
