package com.valtech.project.loneService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoneServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoneServiceApplication.class, args);
	}

}
