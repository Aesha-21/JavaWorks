package com.valtech.training.springSecurity_jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
