package com.valtech.project.netflix.register_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
