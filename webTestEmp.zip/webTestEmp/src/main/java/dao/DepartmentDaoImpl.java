package dao;

import java.net.Authenticator.RequestorType;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import javax.management.RuntimeErrorException;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpSession;
import servlets.DeptServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class DepartmentDaoImpl implements DeptDAO {
	
	
//	private DeptDAO deptDao;
	
	private EmployeeDAO empimpl;
	
	
//----------------------------------------
	static {
		try {
			Class.forName("org.postgresql.Driver");
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
	public ServletContext context;
	
	public DepartmentDaoImpl(ServletContext context,EmployeeDAO emp) {
		this.context = context;
		this.empimpl=emp;
	}

	
	
	//create Get connection method
	
	public DepartmentDaoImpl() {
		// TODO Auto-generated constructor stub
	}



	public Connection getConnection(ServletContext context) throws SQLException{
		try {
			
			   String dbUrl = (String) context.getAttribute("dbUrl");
		       String dbUsername = (String) context.getAttribute("dbUsername");
		       String dbPassword = (String) context.getAttribute("dbPassword");
			
		       Class.forName("org.postgresql.Driver");
		       return DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
		       
					
		        } catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					throw new SQLException("Driver NOF.....");
				}catch(SQLException e) {
					throw new SQLException("Failed to connect DB.....");

				}

	}
	
	
	
private Dept populatDept(ResultSet rs) throws SQLException {
		
		Dept d = Dept.builder().id(rs.getInt(1)).
				name(rs.getString(2)).
				location(rs.getString(3)).build();
		
		return d;
	}



//Dept current = (Dept) HttpSession.getAttribute("current");

//Dept current = (Dept) context.getAttribute("current");



@Override
public List<Employee> getEmployeebyId(int dept_id) {
	
	//HttpSession session = dept_id;
	List<Employee> emps = new ArrayList<Employee>();
	
	try(Connection conn = getConnection(this.context)){
		
		//SELECT * FROM emp AS e JOIN dept AS d ON d.did = e.dept_id;
		//PreparedStatement ps = conn.prepareStatement("SELECT ID,NAME,AGE,GENDER,SALARY,EXPERIANCE,LEVEL,DEPT_ID FROM EMPLOYEE AS e JOIN dept AS d ON d.did = e.dept_id WHERE e.dept_id = d.did");
		//PreparedStatement ps = conn.prepareStatement("SELECT ID,NAME,AGE,GENDER,SALARY,EXPERIANCE,LEVEL,DEPT_ID FROM EMPLOYEE WHERE dept_id = (SELECT DEPT_ID FROM DEPT)");
		
		//current.getId();
		
		PreparedStatement ps = conn.prepareStatement("SELECT ID,NAME,AGE,GENDER,SALARY,EXPERIANCE,LEVEL,DEPT_ID FROM EMPLOYEE WHERE DEPT_ID = ?");
		
		ps.setInt(1, dept_id);
		
//		ps.setInt(1, current.getId());
		
		ResultSet rs = ps.executeQuery();

		//if this next return true when we have another row. and return false when we have end of resultset
		
		while(rs.next()) {
			
			emps.add(empimpl.populateEmployee(rs));
			
			
		} 
		
	}catch(Exception ex) {
		
		throw new RuntimeException(ex);
	}
	
	return emps;
	
	
}

	



	@Override
	public Dept get(int id) {
		
		try(Connection conn = getConnection(this.context)){
			
			PreparedStatement ps = conn.prepareStatement("SELECT DID,DNAME,LOCATION FROM DEPT WHERE DID=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				Dept d = populatDept(rs);
				return d;
			}else {
				new RuntimeException("No id is there"+id);
			}
			
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
		return null;
		
	}
	
	
	//get the all department
	
	@Override
	public List<Dept> getAll(){
		
		List<Dept> depts = new ArrayList<Dept>();
		try(Connection conn = getConnection(context)){
			System.out.println("Inside the first method");
			PreparedStatement ps = conn.prepareStatement("SELECT DID,DNAME,LOCATION FROM DEPT");

			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				System.out.println("Inside the next method");
				depts.add(populatDept(rs));
			}
			
		}catch(Exception e) {
			new RuntimeException(e);
		}
		System.out.println("Depts"+depts);
		return depts;
   
	}
	
	
	
	public void save(Dept dept) {
		
//		try(Connection conn = getConnection()){
//			
//		}catch() {
//			
//		}
		
		
	}
	
	
	public void update(Dept dept) {
		
		
	}
	
	public Dept getDept(int id) {
		return null;
	}
	
	
	public void delete(int id) {
	}
	
	
	


	



	@Override
	public Dept first() {
//		System.out.println("In the first Method");
//		System.out.println(this.getAll());
		//return this.get(this.getAll().stream().mapToInt(e->e.getId()).min().orElseThrow());
		
		
		try(Connection conn = getConnection(this.context)){
			
			DeptDAO dao = new DepartmentDaoImpl(); 
					
			PreparedStatement ps = conn.prepareStatement("SELECT DID,DNAME,LOCATION FROM DEPT  WHERE DID = (SELECT MIN(DID) FROM DEPT )");
//			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
					Dept d = populatDept(rs);
					return d;
			}
			else {
				return null;
			//	return dao.first();
			}
					
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
		
		
	}

	@Override
	public Dept last() {
		//return this.get(this.getAll().stream().mapToInt(e->e.getId()).max().orElseThrow());
		
		try(Connection conn = getConnection(this.context)){
			
			DeptDAO dao = new DepartmentDaoImpl(); 
					
			PreparedStatement ps = conn.prepareStatement("SELECT DID,DNAME,LOCATION FROM DEPT  WHERE DID = (SELECT MAX(DID) FROM DEPT )");
//			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
					Dept d = populatDept(rs);
					return d;
			}
			else {
				return null;
			//	return dao.first();
			}
					
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
		

	}

	@Override
	public Dept next(int id) {
		

		try(Connection conn = getConnection(this.context)){
			
			DeptDAO dao = new DepartmentDaoImpl(); 
					
			PreparedStatement ps = conn.prepareStatement("SELECT DID,DNAME,LOCATION FROM DEPT WHERE DID = (SELECT MIN(DID) FROM DEPT WHERE DID > ?)");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
					Dept d = populatDept(rs);
					return d;
			}
			else {
				return this.first();
			}
					
		}catch(Exception e) {
			throw new RuntimeException(e);
		}
		//return depts;
		

		
		//---------return get(id+1);
		
	}

	@Override
	public Dept previous(int id) {
		

		try(Connection conn = getConnection(this.context)){
			
			DeptDAO dao = new DepartmentDaoImpl(); 
					
			PreparedStatement ps = conn.prepareStatement("SELECT DID,DNAME,LOCATION FROM DEPT WHERE DID = (SELECT MAX(DID) FROM DEPT WHERE DID < ?)");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
					Dept d = populatDept(rs);
					return d;
			}
			else {
				return this.first();
			}
					
		}catch(Exception e) {
			throw new RuntimeException();
		
		//-------return this.get(id-1);
		
	}
	}

	



	



}
