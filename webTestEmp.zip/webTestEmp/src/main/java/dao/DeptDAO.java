package dao;

import java.util.List;
import java.util.Set;

public interface DeptDAO {
	
	Dept first();
	Dept last();
	Dept next(int id);
	Dept previous(int id);
	
	void save(Dept dept);
	void update(Dept dept);
	void delete (int id);
	Dept getDept(int id);
	
	Dept get(int id);
	
	
	
	List<Employee>getEmployeebyId(int dept_id);
	
	List<Dept> getAll();
	

}