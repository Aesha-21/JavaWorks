package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.management.RuntimeErrorException;
import javax.naming.Context;

import dao.Employee.Gender;
import jakarta.servlet.Servlet;
import jakarta.servlet.ServletContext;

//import org.postgresql.shaded.com.ongres.scram.common.bouncycastle.pbkdf2.RuntimeCryptoException;

public class EmployeeDAOImpl implements EmployeeDAO {

	static {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public EmployeeDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	public ServletContext context;

	public EmployeeDAOImpl(ServletContext context) {
		this.context = context;

	}

	public Connection getConnection(ServletContext context) throws SQLException {

		try {

			String dbUrl = (String) context.getAttribute("dbUrl");
			String dbUsername = (String) context.getAttribute("dbUsername");
			String dbPassword = (String) context.getAttribute("dbPassword");

			Class.forName("org.postgresql.Driver");
			return DriverManager.getConnection(dbUrl, dbUsername, dbPassword);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new SQLException("Driver NOF.....");
		} catch (SQLException e) {
			throw new SQLException("Failed to connect DB.....");

		}

	}

	@Override
	public void save(Employee e) {

		try (Connection conn = getConnection(this.context)) {
			PreparedStatement ps = conn.prepareStatement(
					"INSERT INTO EMPLOYEE (NAME,AGE,GENDER,SALARY,EXPERIANCE,LEVEL,ID,DEPT_ID) VALUES (?,?,?,?,?,?,?,?)");

			setValuesToPrepareStatement(e, ps);

			int rowsAffected = ps.executeUpdate();
			System.out.println("Rows insterted" + rowsAffected);

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public void update(Employee e) {
		try (Connection conn = getConnection(this.context)) {
			PreparedStatement ps = conn.prepareStatement(
					"UPDATE EMPLOYEE SET NAME=?, AGE=?, GENDER=?,SALARY=?,EXPERIANCE=?,LEVEL=?,DEPT_ID=? WHERE ID=?");

			setValuesToPrepareStatement(e, ps);

			int rowsAffected = ps.executeUpdate();
			System.out.println("Rows insterted" + rowsAffected);

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private void setValuesToPrepareStatement(Employee e, PreparedStatement ps) throws SQLException {
		ps.setString(1, e.getName());
		ps.setInt(2, e.getAge());
		ps.setString(3, e.getGender().name());
		ps.setFloat(4, e.getSalary());
		ps.setInt(5, e.getExp());
		ps.setInt(6, e.getLevel());
		ps.setInt(7, e.getDept_id());
		ps.setLong(8, e.getId());
	}

	@Override
	public Employee get(int id) {
		try (Connection conn = getConnection(this.context)) {
			PreparedStatement ps = conn.prepareStatement(
					"SELECT ID,NAME,AGE,GENDER,SALARY,EXPERIANCE,LEVEL,DEPT_ID FROM EMPLOYEE WHERE ID = ?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			// if this next return true when we have another row. and return false when we
			// have end of resultset
			if (rs.next()) {

				
				Employee e = populateEmployee(rs);

				return e;

			} else {
				new RuntimeException("No id existis in db" + id);
			}

		} catch (Exception ex) {

			throw new RuntimeException(ex);
		}
		return null;
	}

	public Employee populateEmployee(ResultSet rs) throws SQLException {

		Employee e = Employee.builder().id(rs.getLong(1)).name(rs.getString(2)).age(rs.getInt(3))
				.gender(Gender.valueOf(rs.getString(4))).salary(rs.getFloat(5)).exp(rs.getInt(6)).level(rs.getInt(7))
				.dept_id(rs.getInt(8)).build();
		return e;
	}

	@Override
	public List<Employee> getAll() {
		List<Employee> emps = new ArrayList<Employee>();
		try (Connection conn = getConnection(this.context)) {
			PreparedStatement ps = conn
					.prepareStatement("SELECT ID,NAME,AGE,GENDER,SALARY,EXPERIANCE,LEVEL,DEPT_ID FROM EMPLOYEE");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				emps.add(populateEmployee(rs));
			}

		} catch (Exception e) {
			new RuntimeException(e);
		}

		return emps;

	}

	@Override
	public void delete(int id) {
		try (Connection conn = getConnection(this.context)) {
			PreparedStatement ps = conn.prepareStatement("DELETE FROM EMPLOYEE WHERE ID=?");
			ps.setInt(1, id);

			int rowsAffected = ps.executeUpdate();
			System.out.println("Rows affected" + rowsAffected);

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/// ------------------------------------------SEARCH EMPLOYEE------------------------------------------///

	@Override
	public List<Employee> searchEmpnm(String n) {
		
		List<Employee> emplst = getAll();

		return emplst.stream().filter(e -> e.getName().contains(n)).collect(Collectors.toList());
	}

	@Override
	public List<Employee> searchEmpAge(String byage, int age) {
		
		List<Employee> emplst = getAll();
		
		return emplst.stream().filter(e -> e.getAge()==age?e.getAge()<=age:e.getAge()>=age).collect(Collectors.toList());
	}

	@Override
	public List<Employee> searchEmpSalry(String bysal, float sal) {
		

		List<Employee> emplst = getAll();
		return emplst.stream().filter(e -> e.getSalary()==sal ? e.getSalary()<=sal : e.getSalary()>=sal).collect(Collectors.toList());
		
		
	}
	
	

	// @Override
//	public List<Employee> searchEmp(String selectcol,String srchqury) {
//		
//		List<Employee> emplst = new ArrayList<Employee>();
//		
//		StringBuilder query = new StringBuilder("SELECT * FROM EMPLOYEE WHERE 1=1 ");
//		
//		if(selectcol != null && !selectcol.isEmpty() && srchqury!=null && !srchqury.isEmpty())
//		{
//			if(selectcol.equals("name")) {
//				
//				query.append("AND name LIKE ?");
//				
//			} else if(selectcol.equals("age")) {
//				
//				query.append("AND age LIKE ?");
//
//			}
//		}
//		
//	try(Connection conn = getConnection(this.context)){
//			
//		PreparedStatement ps = conn.prepareStatement(query.toString());
//		if(selectcol != null && !selectcol.isEmpty() && srchqury!=null && !srchqury.isEmpty()) {
//		
//			ps.setString(1,"%" + srchqury + "%");
//		}
//		ResultSet rs = ps.executeQuery();
//		while(rs.next()) {
//			
//				emplst.add(populateEmployee(rs));
//			}
//		
////		try(ResultSet rs = ps.executeQuery()){
////			while(rs.next()) {
////			
////				emplst.add(populateEmployee(rs));
////			}
////		}
//		
//			
//		}catch(SQLException ex){
//			ex.printStackTrace();
//		}
//		
//		
//		return emplst;
//		
//	}

}
