package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.ServletContext;

public interface EmployeeDAO {
	
	void save (Employee e);
	
	void update(Employee e);
	
	void delete(int id);
	
	List<Employee> getAll();
	
	Employee get(int id);

	public Employee populateEmployee(ResultSet rs)throws SQLException;
	
	List<Employee> searchEmpnm(String n);
	List<Employee> searchEmpAge(String byage, int age);
	List<Employee> searchEmpSalry(String bysal, float f);

}
