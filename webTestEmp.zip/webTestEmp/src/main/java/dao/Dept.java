package dao;

public class Dept {
	
	private int id;
	private String name;
	private String location;
	
	public Dept() {}
	
	//create constructor of Department
	public Dept(int id, String name, String location) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
	}
	
	//create builder class for create obj without contructor
	
	public static class DeptBuilder{
		
		private Dept dpt;
		
		//if you want create builder obj so you have to first call dept obj and using dept obj you create bulder obj
		//this is a deptbuilder contructor
		public  DeptBuilder(Dept dpt) {
			this.dpt = dpt;
		}
		
		//return the obj of dept when we call .build()
		public Dept build() {
			return dpt;
		}
		
		
		public DeptBuilder id(int id) {
			dpt.setId(id);
			return this;
		}
		
		@Override
		public String toString() {
			return "DeptBuilder []";
		}

		public DeptBuilder name(String name) {
			dpt.setName(name);
			return this;
		}
		
		public DeptBuilder location(String location) {
			dpt.setLocation(location);
			return this;
		}
		
	}
	
	//here we use emp constructor
	public static DeptBuilder builder() {
		return new DeptBuilder(new Dept());
	}
	
	
	//getter and setters
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	

}
