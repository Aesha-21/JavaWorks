package servlets;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.eclipse.tags.shaded.org.apache.xalan.xsltc.dom.CurrentNodeListFilter;

import dao.DepartmentDaoImpl;
import dao.Dept;
import dao.DeptDAO;
import dao.Employee;
import dao.EmployeeDAO;
import dao.EmployeeDAOImpl;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.*;

@WebServlet(urlPatterns = "/depts")

public class DeptServlet extends HttpServlet{
	
	
	private DeptDAO deptDAO;
	private EmployeeDAO empl;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		
		ServletContext context = config.getServletContext();
		
		empl=new EmployeeDAOImpl();
		
		deptDAO = new DepartmentDaoImpl(context,empl);
		
		
//		deptDAO = new DepartmentDaoImpl(); 
		
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String operation = req.getParameter("operation");
		
		HttpSession session = req.getSession();
		
		Dept current = (Dept) session.getAttribute("current");
		
		if(current == null) {
			current = deptDAO.first();
			
		
		}else {
			
			if("First".equals(operation)) {
				current = deptDAO.first();
				
			}else if("Last".equals(operation)) {
				current = deptDAO.last();
				
			}else if("Previous".equals(operation)) {
				current = deptDAO.previous(current.getId());
				
			}else {
				current = deptDAO.next(current.getId());
				
			}
			
			
		}
		
		//write session
		
		session.setAttribute("current", current);
		req.setAttribute("dept", current);
		
		
		List<Employee> emp = deptDAO.getEmployeebyId(current.getId());
		req.setAttribute("emps", emp);
		
		Cookie [] cookies = req.getCookies();
		for(int i =0; i < cookies.length; i++){
			System.out.println(cookies[i].getName()+ "  "+cookies[i].getValue());
			System.out.println(" Thsi is Cokkies");
			
		}
		
		
		resp.addCookie(new Cookie("operation",operation));
		
		
		
		
		
		
		req.getRequestDispatcher("Department.jsp").forward(req, resp);;

	}
	
	
	
	
	
	
	
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		req.setAttribute("dept", deptDAO.first());
		
		HttpSession session = req.getSession();
		
		Dept current = (Dept) session.getAttribute("current");
		if(current==null) {
			current=deptDAO.first();
			session.setAttribute("current", deptDAO.first());
		}
		
		
		
		req.setAttribute("dept", current);
		
		
		
		List<Employee> emp = deptDAO.getEmployeebyId(current.getId());
		
		System.out.println(emp);
		
	////-------------------------- make 3 string variable opera,arr,sort_by  then if(opr == sort) if (arr == asc) return stream().sort else(sortby)
		
			//Dept current = (Dept) session.getAttribute("current");		
			//session.setAttribute("current", current);
			
			String operation = req.getParameter("operation");
			Object filed = req.getParameter("filed");
			Object sortby =req.getParameter("sortby");
			
			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> Long.compare(e1.getId(),e2.getId())) .collect(Collectors.toList());
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> Long.compare(e2.getId(),e1.getId())) .collect(Collectors.toList());
					}	
				}
			}
		
			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> e1.getName().compareTo(e2.getName())) .collect(Collectors.toList());
					
						//emp = emp.stream().sorted((e1,e2)-> );
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> e2.getName().compareTo(e1.getName())) .collect(Collectors.toList());
					}	
				}
			}

			//age

			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> Integer.compare(e1.getAge(),e2.getAge())).collect(Collectors.toList());
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> Integer.compare(e2.getAge(),e1.getAge())).collect(Collectors.toList());
					}	
				}
			}

		
			//Gender
			
			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> e1.getGender().compareTo(e2.getGender())) .collect(Collectors.toList());
					
						//emp = emp.stream().sorted((e1,e2)-> );
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> e2.getGender().compareTo(e1.getGender())) .collect(Collectors.toList());
					}	
				}
			}
			
			//Salary
			
			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> Float.compare(e1.getSalary(),e2.getSalary())).collect(Collectors.toList());
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> Float.compare(e2.getSalary(),e1.getSalary())).collect(Collectors.toList());
					}	
				}
			}
			
			//Experiance
			
			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> Integer.compare(e1.getExp(),e2.getExp())).collect(Collectors.toList());
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> Integer.compare(e2.getExp(),e1.getExp())).collect(Collectors.toList());
					}	
				}
			}
			
			//level
			
			if("sorting" .equals(operation)) {
				
				if("name".equals(filed)) {
					
					if("asc".equals(sortby)) {	
						
						emp = emp.stream().sorted((e1,e2)-> Integer.compare(e1.getLevel(),e2.getLevel())).collect(Collectors.toList());
					}
					else if("dsc".equals(sortby)) {
						
						emp = emp.stream().sorted((e1,e2)-> Integer.compare(e2.getLevel(),e1.getLevel())).collect(Collectors.toList());
					}	
				}
			}
			
			
			
			//get all the data from the table
			req.setAttribute("dept", current);
			
			//session.setAttribute("current", current);
			
			session.setAttribute("emps", emp);
			
			req.setAttribute("emps", emp);
		
		
		req.getRequestDispatcher("Department.jsp").forward(req, resp);
		

		
	}



	

}
