package servlets;

import java.io.InputStream;
import java.util.Properties;

import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;

public class LoadConfigListners implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("First config listners");
		
		//ServletContext application = sce.getServletContext();
		
		
		Properties dbproperties = new Properties();
		
		try {

		InputStream inputStream = getClass().getClassLoader().getResourceAsStream("db.properties");
			
		if(inputStream != null) {
			
		
			dbproperties.load(inputStream);
		}else {
			System.out.println("DB file not found");
		} 
		
		ServletContext context = sce.getServletContext();
		
		context.setAttribute("dbUrl", dbproperties.getProperty("db.url"));
		context.setAttribute("dbUsername", dbproperties.getProperty("db.username"));
		context.setAttribute("dbPassword", dbproperties.getProperty("db.password"));
		context.setAttribute("dbDriver", dbproperties.getProperty("db.driver"));


		
		
		}catch(Exception e) {
			e.printStackTrace();
		}	
		
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("Closing all db conneciton");
	}
}
