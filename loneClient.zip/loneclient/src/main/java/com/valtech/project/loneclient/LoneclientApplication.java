package com.valtech.project.loneclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoneclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoneclientApplication.class, args);
	}

}
