package com.valtech.project.loneclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoneclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
