package com.valtech.project.CustOrder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerOrderSpringMvcProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerOrderSpringMvcProjectApplication.class, args);
	}

}
