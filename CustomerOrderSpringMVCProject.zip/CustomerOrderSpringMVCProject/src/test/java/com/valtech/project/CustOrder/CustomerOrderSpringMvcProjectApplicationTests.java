package com.valtech.project.CustOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerOrderSpringMvcProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
