package com.valtech.project.QuizeService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
